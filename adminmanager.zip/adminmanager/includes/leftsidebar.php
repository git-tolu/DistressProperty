 <aside  class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <!-- User Profile-->
                       
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark" href="dashboard" aria-expanded="false"><i class="mdi mdi-view-dashboard"></i><span class="hide-menu">Dashboard </span></a>
                          
                        </li>
                        <!-- <li class="sidebar-item"> <a class="sidebar-link  waves-effect waves-dark" href="pendingmembers" aria-expanded="false"><i class="mdi mdi-account-star"></i><span class="hide-menu">Application </span></a>
                      
                        </li> -->
						<li class="sidebar-item"> <a class="sidebar-link  waves-effect waves-dark" href="pendingpost" aria-expanded="false"><i class="mdi mdi-wallet-membership"></i><span class="hide-menu">Posts </span></a>
                        </li>
                        <!-- 
						
						
                      
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="paymenthistoryad" aria-expanded="false"><i class="mdi mdi-treasure-chest"></i><span class="hide-menu">Payment history</span></a></li>
                        -->
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link" href="logout" aria-expanded="false"><i class="mdi mdi mdi-power"></i><span class="hide-menu">Log Out</span></a></li>
                    </ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>