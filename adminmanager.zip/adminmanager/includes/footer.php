<footer class="footer text-center">
    <a href="index">Distress Property Market</a> &copy;
    <?= Date('Y') ?> All Right Reserved.
</footer>