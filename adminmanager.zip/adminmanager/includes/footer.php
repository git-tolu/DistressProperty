<footer class="footer text-center">
 All Rights Reserved by Xero Real. Developed by <a href="https://uptechng.com" target="blank">UPTECH</a>.
</footer>
           