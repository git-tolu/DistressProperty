<?php
$dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
   $dbname = 'xeroreal';
   $conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
?>